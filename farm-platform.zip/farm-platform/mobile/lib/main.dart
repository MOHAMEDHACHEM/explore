import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'core/api.dart';
import 'core/local_db.dart';
import 'screens/home_shell.dart';
import 'screens/login_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const FarmApp());
}

class FarmApp extends StatelessWidget {
  const FarmApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'تسيير المزرعة',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('fr')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: const Color(0xFF2B5A3C)),
      darkTheme: ThemeData(
          useMaterial3: true,
          colorSchemeSeed: const Color(0xFF2B5A3C),
          brightness: Brightness.dark),
      home: const Gate(),
    );
  }
}

class Gate extends StatefulWidget {
  const Gate({super.key});
  @override
  State<Gate> createState() => _GateState();
}

class _GateState extends State<Gate> {
  bool? _in;

  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    final v = (await Api.hasToken()) || (await LocalDb.isLocal());
    if (mounted) setState(() => _in = v);
  }

  @override
  Widget build(BuildContext context) {
    if (_in == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return _in!
        ? HomeShell(onLogout: () => setState(() => _in = false))
        : LoginScreen(onDone: () => setState(() => _in = true));
  }
}
