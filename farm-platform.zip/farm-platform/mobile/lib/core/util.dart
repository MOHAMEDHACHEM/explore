String today() => DateTime.now().toIso8601String().substring(0, 10);

/// الزيادة اليومية بالغرام من أول وزن إلى آخر وزن. null إن لم يكن هناك وزنان.
double? adgGrams(List<Map<String, dynamic>> weights) {
  if (weights.length < 2) return null;
  final w = [...weights]..sort((a, b) => (a['date'] as String).compareTo(b['date'] as String));
  final days = DateTime.parse(w.last['date'] as String)
      .difference(DateTime.parse(w.first['date'] as String))
      .inDays;
  if (days <= 0) return null;
  return ((w.last['kg'] as num) - (w.first['kg'] as num)) * 1000 / days;
}

double? parseNum(String s) => double.tryParse(s.trim().replaceAll(',', '.'));
