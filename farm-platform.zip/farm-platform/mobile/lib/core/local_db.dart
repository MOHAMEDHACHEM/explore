import 'dart:convert';

import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:uuid/uuid.dart';

/// تخزين محلي عام: جدول واحد لكل الكيانات (نفس بروتوكول المزامنة مع الخادم).
/// dirty: 0 متزامن، 1 ينتظر الدفع، 2 رفضه الخادم.
class LocalDb {
  static Database? _db;

  static Future<Database> get db async => _db ??= await openDatabase(
        join(await getDatabasesPath(), 'farm.db'),
        version: 1,
        onCreate: (d, v) async {
          await d.execute('CREATE TABLE records('
              'entity TEXT, id TEXT, data TEXT, client_ts INTEGER, '
              'dirty INTEGER, deleted INTEGER, PRIMARY KEY(entity, id))');
          await d.execute('CREATE INDEX idx_dirty ON records(dirty)');
          await d.execute('CREATE TABLE meta(k TEXT PRIMARY KEY, v TEXT)');
        },
      );

  static Future<List<Map<String, dynamic>>> list(String entity) async {
    final rows = await (await db)
        .query('records', where: 'entity = ? AND deleted = 0', whereArgs: [entity]);
    return rows.map((r) => jsonDecode(r['data'] as String) as Map<String, dynamic>).toList();
  }

  /// حفظ محلي فوري (يعمل بلا إنترنت) ويُدفع عند أول مزامنة.
  static Future<Map<String, dynamic>> save(String entity, Map<String, dynamic> rec) async {
    final now = DateTime.now().millisecondsSinceEpoch;
    rec['id'] ??= const Uuid().v4().replaceAll('-', '');
    rec['client_ts'] = now;
    rec['deleted'] = rec['deleted'] ?? false;
    await (await db).insert(
        'records',
        {
          'entity': entity,
          'id': rec['id'],
          'data': jsonEncode(rec),
          'client_ts': now,
          'dirty': 1,
          'deleted': rec['deleted'] == true ? 1 : 0,
        },
        conflictAlgorithm: ConflictAlgorithm.replace);
    return rec;
  }

  static Future<void> remove(String entity, Map<String, dynamic> rec) =>
      save(entity, {...rec, 'deleted': true});

  static Future<List<Map<String, Object?>>> dirty() async =>
      (await db).query('records', where: 'dirty = 1');

  static Future<int> pendingCount() async => Sqflite.firstIntValue(
      await (await db).rawQuery('SELECT COUNT(*) FROM records WHERE dirty = 1')) ?? 0;

  static Future<int> rejectedCount() async => Sqflite.firstIntValue(
      await (await db).rawQuery('SELECT COUNT(*) FROM records WHERE dirty = 2')) ?? 0;

  /// لا نُنظّف السجل إن تعدّل محليًا أثناء المزامنة (client_ts تغيّر).
  static Future<void> markDone(String entity, String id, int ts, int dirty) async =>
      (await db).update('records', {'dirty': dirty},
          where: 'entity = ? AND id = ? AND client_ts = ?', whereArgs: [entity, id, ts]);

  static Future<void> applyPulled(String entity, Map<String, dynamic> rec) async {
    final d = await db;
    final cur = await d.query('records',
        where: 'entity = ? AND id = ?', whereArgs: [entity, rec['id']]);
    if (cur.isNotEmpty &&
        cur.first['dirty'] == 1 &&
        (cur.first['client_ts'] as int) > ((rec['client_ts'] ?? 0) as int)) {
      return; // تعديلي المحلي أحدث وسيُدفع في المزامنة القادمة
    }
    await d.insert(
        'records',
        {
          'entity': entity,
          'id': rec['id'],
          'data': jsonEncode(rec),
          'client_ts': rec['client_ts'] ?? 0,
          'dirty': 0,
          'deleted': rec['deleted'] == true ? 1 : 0,
        },
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  static Future<String?> meta(String k) async {
    final r = await (await db).query('meta', where: 'k = ?', whereArgs: [k]);
    return r.isEmpty ? null : r.first['v'] as String;
  }

  static Future<void> setMeta(String k, String v) async => (await db)
      .insert('meta', {'k': k, 'v': v}, conflictAlgorithm: ConflictAlgorithm.replace);

  static Future<bool> isLocal() async => (await meta('mode')) == 'local';

  /// بيانات أولية للوضع المحلي (في وضع الخادم يزرعها الخادم عند التسجيل).
  static Future<void> seedDefaults() async {
    for (final (n, k, b) in [
      ('أولاد جلال', 'sheep', 'أولاد جلال'),
      ('الرمبي', 'sheep', 'الرمبي'),
      ('الحمراء', 'sheep', 'الحمراء'),
      ('الماعز', 'goat', ''),
      ('دجاج البياض', 'layers', ''),
      ('دجاج اللحم', 'broilers', ''),
      ('دجاج الزينة', 'ornamental', ''),
    ]) {
      await save('group', {'name': n, 'kind': k, 'breed': b, 'qty': 0});
    }
    for (final (n, use) in [('شعير', 6.0), ('فصة مجففة', 2.5), ('علف البياض', 1.2), ('علف اللحم', 8.0)]) {
      await save('stock_item', {'name': n, 'unit': 'قنطار', 'opening': 0.0, 'daily_use': use, 'min_days': 10});
    }
  }

  static Future<void> wipe() async {
    final d = await db;
    await d.delete('records');
    await d.delete('meta');
  }
}
