import 'package:flutter/material.dart';

/// نافذة إدخال عدة حقول رقمية. تعيد null عند الإلغاء.
Future<List<String>?> askFields(BuildContext context, String title, List<String> labels,
    {List<String>? initial}) {
  final cs = [
    for (var i = 0; i < labels.length; i++) TextEditingController(text: initial != null ? initial[i] : '')
  ];
  return showDialog<List<String>>(
      context: context,
      builder: (ctx) => AlertDialog(
            title: Text(title),
            content: SingleChildScrollView(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
              for (var i = 0; i < labels.length; i++)
                TextField(
                    controller: cs[i],
                    autofocus: i == 0,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: InputDecoration(labelText: labels[i])),
            ])),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
              FilledButton(
                  onPressed: () => Navigator.pop(ctx, [for (final c in cs) c.text.trim()]),
                  child: const Text('حفظ')),
            ],
          ));
}

void snack(BuildContext context, String message) =>
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
