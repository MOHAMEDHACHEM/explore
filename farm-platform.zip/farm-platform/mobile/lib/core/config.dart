/// عنوان الخادم. غيّره عند البناء: flutter run --dart-define=API_BASE=https://farm.example.dz
/// 10.0.2.2 يشير إلى حاسوبك من داخل محاكي أندرويد.
const apiBase = String.fromEnvironment('API_BASE', defaultValue: 'http://10.0.2.2:8000');
