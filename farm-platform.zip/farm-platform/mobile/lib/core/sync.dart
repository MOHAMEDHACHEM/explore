import 'dart:convert';

import 'api.dart';
import 'local_db.dart';

class SyncResult {
  final bool ok;
  final int pushed;
  final int rejected;
  final String? error;
  const SyncResult({required this.ok, this.pushed = 0, this.rejected = 0, this.error});
}

bool _running = false;

Future<SyncResult> syncNow() async {
  if (_running || await LocalDb.isLocal()) return const SyncResult(ok: true);
  _running = true;
  try {
    final dirty = await LocalDb.dirty();
    final changes = <String, List<Map<String, dynamic>>>{};
    for (final r in dirty) {
      final data = jsonDecode(r['data'] as String) as Map<String, dynamic>;
      data['deleted'] = r['deleted'] == 1;
      (changes[r['entity'] as String] ??= []).add(data);
    }
    final last = int.tryParse(await LocalDb.meta('last_pulled') ?? '0') ?? 0;
    final res = await Api.sync(last, changes);
    final rejected = <String>{
      for (final x in (res['rejected'] as List)) '${x['entity']}:${x['id']}'
    };
    for (final r in dirty) {
      final key = '${r['entity']}:${r['id']}';
      await LocalDb.markDone(r['entity'] as String, r['id'] as String,
          r['client_ts'] as int, rejected.contains(key) ? 2 : 0);
    }
    for (final e in (res['changes'] as Map<String, dynamic>).entries) {
      for (final rec in e.value as List) {
        await LocalDb.applyPulled(e.key, Map<String, dynamic>.from(rec as Map));
      }
    }
    await LocalDb.setMeta('last_pulled', '${res['server_time']}');
    return SyncResult(ok: true, pushed: dirty.length - rejected.length, rejected: rejected.length);
  } on ApiException catch (e) {
    return SyncResult(ok: false, error: e.message);
  } catch (_) {
    return const SyncResult(ok: false, error: 'لا يوجد اتصال. التعديلات محفوظة وستُزامَن لاحقًا');
  } finally {
    _running = false;
  }
}
