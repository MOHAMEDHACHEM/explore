import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

import 'config.dart';

class ApiException implements Exception {
  final int status;
  final String message;
  ApiException(this.status, this.message);
  @override
  String toString() => message;
}

class Api {
  static const _store = FlutterSecureStorage();

  static Future<String?> token() => _store.read(key: 'token');
  static Future<bool> hasToken() async => (await token()) != null;
  static Future<void> logout() => _store.delete(key: 'token');

  static String _msg(http.Response r) {
    try {
      final d = jsonDecode(utf8.decode(r.bodyBytes))['detail'];
      if (d is String) return d;
    } catch (_) {}
    return 'تعذّر تنفيذ الطلب';
  }

  static Future<void> login(String email, String password) async {
    final r = await http
        .post(Uri.parse('$apiBase/api/auth/login'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'email': email.trim(), 'password': password}))
        .timeout(const Duration(seconds: 20));
    if (r.statusCode != 200) throw ApiException(r.statusCode, _msg(r));
    final data = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
    await _store.write(key: 'token', value: data['token'] as String);
    await _store.write(key: 'role', value: (data['user'] as Map)['role'] as String);
  }

  static Future<String> role() async => (await _store.read(key: 'role')) ?? 'worker';

  /// دفع التعديلات المحلية وسحب تعديلات الخادم في طلب واحد.
  static Future<Map<String, dynamic>> sync(
      int lastPulled, Map<String, List<Map<String, dynamic>>> changes) async {
    final t = await token();
    if (t == null) throw ApiException(401, 'سجّل الدخول من جديد');
    final r = await http
        .post(Uri.parse('$apiBase/api/sync'),
            headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $t'},
            body: jsonEncode({'last_pulled': lastPulled, 'changes': changes}))
        .timeout(const Duration(seconds: 30));
    if (r.statusCode == 401) {
      await logout();
      throw ApiException(401, 'انتهت الجلسة، سجّل الدخول من جديد');
    }
    if (r.statusCode != 200) throw ApiException(r.statusCode, _msg(r));
    return jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
  }
}
