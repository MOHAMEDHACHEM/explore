import 'package:flutter/material.dart';

import '../core/local_db.dart';
import '../core/util.dart';
import '../core/widgets.dart';

class PoultryTab extends StatefulWidget {
  final VoidCallback onChanged;
  const PoultryTab({super.key, required this.onChanged});
  @override
  State<PoultryTab> createState() => _PoultryTabState();
}

class _PoultryTabState extends State<PoultryTab> {
  List<Map<String, dynamic>> _groups = [], _logs = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final g = await LocalDb.list('group');
    final l = await LocalDb.list('daily_log');
    if (!mounted) return;
    setState(() {
      _groups = g.where((x) => const ['layers', 'broilers', 'ornamental'].contains(x['kind'])).toList();
      _logs = l;
    });
  }

  Map<String, dynamic>? _todayLog(String gid) {
    for (final l in _logs) {
      if (l['group_id'] == gid && l['date'] == today()) return l;
    }
    return null;
  }

  num _sum(String gid, String key, int days) {
    final from = DateTime.now().subtract(Duration(days: days)).toIso8601String().substring(0, 10);
    num s = 0;
    for (final l in _logs) {
      if (l['group_id'] == gid && (l['date'] as String).compareTo(from) > 0) s += (l[key] as num? ?? 0);
    }
    return s;
  }

  Future<void> _log(Map<String, dynamic> g) async {
    final isLayer = g['kind'] == 'layers';
    final ex = _todayLog(g['id'] as String);
    final labels = [if (isLayer) 'عدد البيض اليوم', 'النفوق اليوم', 'العلف المستهلك (كلغ)'];
    final init = ex == null ? null : [if (isLayer) '${ex['eggs']}', '${ex['deaths']}', '${ex['feed_kg']}'];
    final r = await askFields(context, 'تسجيل اليوم: ${g['name']}', labels, initial: init);
    if (r == null) return;
    final v = r.map((s) => parseNum(s) ?? 0).toList();
    if (v.any((x) => x < 0)) {
      if (mounted) snack(context, 'لا تُقبل قيم سالبة');
      return;
    }
    var i = 0;
    final eggs = isLayer ? v[i++] : 0.0;
    final deaths = v[i++];
    final feed = v[i];
    await LocalDb.save('daily_log', {
      if (ex != null) 'id': ex['id'],
      'group_id': g['id'],
      'date': today(),
      'eggs': eggs.round(),
      'deaths': deaths.round(),
      'feed_kg': feed,
    });
    widget.onChanged();
    await _load();
  }

  Future<void> _setQty(Map<String, dynamic> g) async {
    final r = await askFields(context, 'عدد ${g['name']}', ['العدد الحالي'], initial: ['${g['qty']}']);
    final n = r == null ? null : parseNum(r.first);
    if (n == null || n < 0) return;
    await LocalDb.save('group', {...g, 'qty': n.round()});
    widget.onChanged();
    await _load();
  }

  Widget _card(Map<String, dynamic> g) {
    final id = g['id'] as String;
    final qty = (g['qty'] as num? ?? 0).toInt();
    final isLayer = g['kind'] == 'layers';
    final t = _todayLog(id);
    final eggsToday = (t?['eggs'] as num? ?? 0).toInt();
    final rate = qty > 0 && eggsToday > 0 ? (eggsToday / qty * 100).round() : null;
    return Card(
        child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text(g['name'] as String, style: Theme.of(context).textTheme.titleMedium),
                Text('$qty رأس', style: Theme.of(context).textTheme.titleMedium),
              ]),
              const SizedBox(height: 6),
              if (isLayer)
                Text('بيض اليوم: $eggsToday${rate != null ? ' ($rate% من الطاقة)' : ''} · آخر 7 أيام: ${_sum(id, 'eggs', 7)}'),
              Text('نفوق آخر 30 يومًا: ${_sum(id, 'deaths', 30)} · علف آخر 7 أيام: ${_sum(id, 'feed_kg', 7).toStringAsFixed(0)} كلغ'),
              const SizedBox(height: 8),
              Wrap(spacing: 8, children: [
                FilledButton.tonal(onPressed: () => _log(g), child: const Text('تسجيل اليوم')),
                OutlinedButton(onPressed: () => _setQty(g), child: const Text('تعديل العدد')),
              ]),
            ])));
  }

  @override
  Widget build(BuildContext context) {
    if (_groups.isEmpty) return const Center(child: Text('لا خطوط دواجن بعد.'));
    return ListView(padding: const EdgeInsets.all(12), children: [for (final g in _groups) _card(g)]);
  }
}
