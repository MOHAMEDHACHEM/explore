import 'package:flutter/material.dart';

import '../core/local_db.dart';
import '../core/util.dart';

class AnimalsTab extends StatefulWidget {
  final VoidCallback onChanged;
  const AnimalsTab({super.key, required this.onChanged});
  @override
  State<AnimalsTab> createState() => _AnimalsTabState();
}

class _AnimalsTabState extends State<AnimalsTab> {
  List<Map<String, dynamic>> _animals = [], _groups = [], _weights = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final a = await LocalDb.list('animal');
    final g = await LocalDb.list('group');
    final w = await LocalDb.list('weight');
    if (!mounted) return;
    setState(() {
      _animals = a.where((x) => x['status'] == 'active').toList()
        ..sort((x, y) => (x['tag'] as String).compareTo(y['tag'] as String));
      _groups = g.where((x) => x['kind'] == 'sheep' || x['kind'] == 'goat').toList();
      _weights = w;
    });
  }

  List<Map<String, dynamic>> _wOf(String id) => _weights.where((w) => w['animal_id'] == id).toList();

  Future<void> _save(String entity, Map<String, dynamic> rec) async {
    await LocalDb.save(entity, rec);
    widget.onChanged();
    await _load();
  }

  Future<String?> _ask(String title, {String? hint, bool number = false}) {
    final c = TextEditingController();
    return showDialog<String>(
        context: context,
        builder: (ctx) => AlertDialog(
              title: Text(title),
              content: TextField(
                  controller: c,
                  autofocus: true,
                  keyboardType: number ? const TextInputType.numberWithOptions(decimal: true) : null,
                  decoration: InputDecoration(hintText: hint)),
              actions: [
                TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
                FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('حفظ')),
              ],
            ));
  }

  Future<void> _addAnimal() async {
    if (_groups.isEmpty) {
      _snack('لا توجد سلالات بعد. زامن أولًا');
      return;
    }
    final tag = TextEditingController();
    String group = _groups.first['id'] as String;
    String sex = 'F';
    final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => StatefulBuilder(
            builder: (ctx, set) => AlertDialog(
                  title: const Text('رأس جديد'),
                  content: Column(mainAxisSize: MainAxisSize.min, children: [
                    TextField(controller: tag, decoration: const InputDecoration(labelText: 'رقم التعريف')),
                    DropdownButtonFormField<String>(
                        value: group,
                        decoration: const InputDecoration(labelText: 'السلالة'),
                        items: [
                          for (final g in _groups)
                            DropdownMenuItem(value: g['id'] as String, child: Text(g['name'] as String))
                        ],
                        onChanged: (v) => set(() => group = v!)),
                    DropdownButtonFormField<String>(
                        value: sex,
                        decoration: const InputDecoration(labelText: 'الجنس'),
                        items: const [
                          DropdownMenuItem(value: 'F', child: Text('أنثى')),
                          DropdownMenuItem(value: 'M', child: Text('ذكر')),
                        ],
                        onChanged: (v) => set(() => sex = v!)),
                  ]),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
                    FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('أضف')),
                  ],
                )));
    if (ok != true || tag.text.trim().isEmpty) return;
    if (_animals.any((a) => a['tag'] == tag.text.trim())) {
      _snack('رقم التعريف مستعمل لرأس آخر');
      return;
    }
    await _save('animal', {'tag': tag.text.trim(), 'group_id': group, 'sex': sex, 'status': 'active'});
  }

  void _snack(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _addWeight(Map<String, dynamic> a) async {
    final v = double.tryParse((await _ask('وزن ${a['tag']} (كلغ)', number: true) ?? '').replaceAll(',', '.'));
    if (v == null || v <= 0 || v >= 500) return;
    // وزن واحد لكل يوم: نحدّث وزن اليوم إن وُجد
    final same = _wOf(a['id']).where((w) => w['date'] == today()).toList();
    await _save('weight', {
      if (same.isNotEmpty) 'id': same.first['id'],
      'animal_id': a['id'],
      'date': today(),
      'kg': v,
    });
  }

  Future<void> _addHealth(Map<String, dynamic> a) async {
    final product = await _ask('اسم الدواء أو اللقاح');
    if (product == null || product.isEmpty) return;
    final days = int.tryParse(await _ask('مدة السحب بالأيام (0 إن لا توجد)', number: true) ?? '0') ?? 0;
    await _save('health', {
      'target_type': 'animal',
      'target_id': a['id'],
      'kind': days > 0 ? 'treatment' : 'vaccine',
      'product': product,
      'date': today(),
      'withdrawal_days': days,
      'note': '',
    });
    _snack(days > 0 ? 'سُجّل العلاج. البيع ممنوع $days يومًا' : 'سُجّل اللقاح');
  }

  Future<void> _sell(Map<String, dynamic> a) async {
    final events = await LocalDb.list('health');
    final now = DateTime.parse(today());
    DateTime? until;
    String product = '';
    for (final e in events) {
      final mine = (e['target_type'] == 'animal' && e['target_id'] == a['id']) ||
          (e['target_type'] == 'group' && e['target_id'] == a['group_id']);
      final days = (e['withdrawal_days'] as num? ?? 0).toInt();
      if (!mine || days <= 0) continue;
      final end = DateTime.parse(e['date'] as String).add(Duration(days: days));
      if (end.isAfter(now) && (until == null || end.isAfter(until))) {
        until = end;
        product = (e['product'] as String?) ?? '';
      }
    }
    if (until != null) {
      _snack('مدة السحب جارية ($product). يُسمح بالبيع من ${until.toIso8601String().substring(0, 10)}');
      return;
    }
    final price = double.tryParse((await _ask('سعر بيع ${a['tag']} (دج)', number: true) ?? '').replaceAll(',', '.'));
    if (price == null || price <= 0) return;
    await LocalDb.save('animal', {...a, 'status': 'sold'});
    await LocalDb.save('transaction', {'date': today(), 'type': 'in', 'category': 'بيع ${a['tag']}', 'amount': price, 'note': ''});
    widget.onChanged();
    await _load();
    _snack('تم البيع وتسجيل الإيراد');
  }

  void _sheet(Map<String, dynamic> a) {
    showModalBottomSheet(
        context: context,
        builder: (ctx) => SafeArea(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
              ListTile(title: Text(a['tag'] as String), subtitle: Text(_groupName(a['group_id']))),
              ListTile(
                  leading: const Icon(Icons.monitor_weight_outlined),
                  title: const Text('تسجيل وزن'),
                  onTap: () {
                    Navigator.pop(ctx);
                    _addWeight(a);
                  }),
              ListTile(
                  leading: const Icon(Icons.vaccines_outlined),
                  title: const Text('تسجيل علاج أو لقاح'),
                  onTap: () {
                    Navigator.pop(ctx);
                    _addHealth(a);
                  }),
              ListTile(
                  leading: const Icon(Icons.sell_outlined),
                  title: const Text('بيع الرأس'),
                  onTap: () {
                    Navigator.pop(ctx);
                    _sell(a);
                  }),
            ])));
  }

  String _groupName(dynamic id) =>
      (_groups.firstWhere((g) => g['id'] == id, orElse: () => {'name': ''})['name'] as String);

  @override
  Widget build(BuildContext context) {
    final err = Theme.of(context).colorScheme.error;
    return Scaffold(
      body: _animals.isEmpty
          ? const Center(child: Text('لا رؤوس بعد. اضغط + لإضافة أول رأس.'))
          : ListView.separated(
              itemCount: _animals.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (c, i) {
                final a = _animals[i];
                final ws = _wOf(a['id'] as String)..sort((x, y) => (x['date'] as String).compareTo(y['date'] as String));
                final g = adgGrams(ws);
                return ListTile(
                  title: Text(a['tag'] as String),
                  subtitle: Text(_groupName(a['group_id'])),
                  trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
                    Text(ws.isEmpty ? '—' : '${ws.last['kg']} كلغ'),
                    if (g != null)
                      Text('${g.round()} غ/يوم',
                          style: TextStyle(fontSize: 12, color: g < 150 ? err : null, fontWeight: g < 150 ? FontWeight.bold : null)),
                  ]),
                  onTap: () => _sheet(a),
                );
              }),
      floatingActionButton: FloatingActionButton(
          onPressed: _addAnimal, tooltip: 'رأس جديد', child: const Icon(Icons.add)),
    );
  }
}
