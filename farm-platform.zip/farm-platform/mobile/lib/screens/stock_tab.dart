import 'package:flutter/material.dart';

import '../core/local_db.dart';
import '../core/util.dart';

class StockTab extends StatefulWidget {
  final VoidCallback onChanged;
  const StockTab({super.key, required this.onChanged});
  @override
  State<StockTab> createState() => _StockTabState();
}

class _StockTabState extends State<StockTab> {
  List<Map<String, dynamic>> _items = [], _moves = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final i = await LocalDb.list('stock_item');
    final m = await LocalDb.list('stock_move');
    if (mounted) setState(() => (_items, _moves) = (i, m));
  }

  double _qty(Map<String, dynamic> it) =>
      (it['opening'] as num).toDouble() +
      _moves.where((m) => m['item_id'] == it['id']).fold<double>(0, (s, m) => s + (m['delta'] as num));

  Future<void> _move(Map<String, dynamic> it, int sign) async {
    final c = TextEditingController();
    final v = await showDialog<double>(
        context: context,
        builder: (ctx) => AlertDialog(
              title: Text('${sign > 0 ? 'استلام' : 'صرف'} ${it['name']}'),
              content: TextField(
                  controller: c,
                  autofocus: true,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: InputDecoration(suffixText: it['unit'] as String)),
              actions: [
                TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
                FilledButton(
                    onPressed: () => Navigator.pop(ctx, double.tryParse(c.text.replaceAll(',', '.'))),
                    child: const Text('حفظ')),
              ],
            ));
    if (v == null || v <= 0) return;
    if (sign < 0 && v > _qty(it)) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('الكمية أكبر من المخزون')));
      return;
    }
    await LocalDb.save('stock_move', {'item_id': it['id'], 'date': today(), 'delta': sign * v, 'note': ''});
    widget.onChanged();
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final err = Theme.of(context).colorScheme.error;
    if (_items.isEmpty) return const Center(child: Text('لا أصناف بعد. زامن لتحميل المخزون.'));
    return ListView.separated(
        itemCount: _items.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (c, i) {
          final it = _items[i];
          final q = _qty(it);
          final use = (it['daily_use'] as num).toDouble();
          final days = use > 0 ? q / use : null;
          final low = days != null && days < (it['min_days'] as num);
          return ListTile(
            title: Text(it['name'] as String),
            subtitle: Text(days == null ? 'الكمية ${q.toStringAsFixed(1)} ${it['unit']}' : 'يكفي ${days.toStringAsFixed(0)} يومًا',
                style: TextStyle(color: low ? err : null, fontWeight: low ? FontWeight.bold : null)),
            trailing: Row(mainAxisSize: MainAxisSize.min, children: [
              Text('${q.toStringAsFixed(1)} ${it['unit']}'),
              IconButton(tooltip: 'استلام', icon: const Icon(Icons.add_circle_outline), onPressed: () => _move(it, 1)),
              IconButton(tooltip: 'صرف', icon: const Icon(Icons.remove_circle_outline), onPressed: () => _move(it, -1)),
            ]),
          );
        });
  }
}
