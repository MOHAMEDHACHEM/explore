import 'package:flutter/material.dart';

import 'finance_tab.dart';
import 'irrigation_screen.dart';
import 'tasks_tab.dart';

class MoreTab extends StatelessWidget {
  final VoidCallback onChanged;
  const MoreTab({super.key, required this.onChanged});

  void _open(BuildContext context, String title, Widget body) => Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(title: Text(title)), body: body)));

  @override
  Widget build(BuildContext context) {
    return ListView(children: [
      ListTile(
          leading: const Icon(Icons.checklist),
          title: const Text('المهام'),
          subtitle: const Text('تلقيح، تنظيف، فحص المضخة...'),
          onTap: () => _open(context, 'المهام', TasksTab(onChanged: onChanged))),
      ListTile(
          leading: const Icon(Icons.payments_outlined),
          title: const Text('المالية'),
          subtitle: const Text('الإيرادات والمصاريف'),
          onTap: () => _open(context, 'المالية', FinanceTab(onChanged: onChanged))),
      ListTile(
          leading: const Icon(Icons.water_drop_outlined),
          title: const Text('الحقول والري'),
          subtitle: const Text('ساعات الري وحصة الماء'),
          onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => IrrigationScreen(onChanged: onChanged)))),
    ]);
  }
}
