import 'package:flutter/material.dart';

import '../core/local_db.dart';
import '../core/util.dart';
import '../core/widgets.dart';

const _fields = ['فصة', 'شعير وذرة'];

class IrrigationScreen extends StatefulWidget {
  final VoidCallback onChanged;
  const IrrigationScreen({super.key, required this.onChanged});
  @override
  State<IrrigationScreen> createState() => _IrrigationScreenState();
}

class _IrrigationScreenState extends State<IrrigationScreen> {
  List<Map<String, dynamic>> _logs = [];
  double _cap = 6000, _flow = 15;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final l = await LocalDb.list('irrigation');
    final cap = parseNum(await LocalDb.meta('water_cap') ?? '') ?? 6000.0;
    final flow = parseNum(await LocalDb.meta('pump_flow') ?? '') ?? 15.0;
    l.sort((a, b) => (b['date'] as String).compareTo(a['date'] as String));
    if (mounted) setState(() => (_logs, _cap, _flow) = (l, cap, flow));
  }

  double get _used {
    final m = today().substring(0, 7);
    return _logs.where((l) => (l['date'] as String).startsWith(m)).fold<double>(0, (s, l) => s + (l['m3'] as num));
  }

  int? _since(String field) {
    for (final l in _logs) {
      if (l['field_name'] == field) return DateTime.parse(today()).difference(DateTime.parse(l['date'] as String)).inDays;
    }
    return null;
  }

  Future<void> _irrigate(String field) async {
    final r = await askFields(context, 'ريّ $field', ['عدد ساعات الري']);
    final h = r == null ? null : parseNum(r.first);
    if (h == null || h <= 0 || h > 240) return;
    await LocalDb.save('irrigation', {'field_name': field, 'date': today(), 'hours': h, 'm3': h * _flow});
    widget.onChanged();
    await _load();
  }

  Future<void> _settings() async {
    final r = await askFields(context, 'إعدادات الماء', ['الحصة الشهرية (م³)', 'تدفق المضخة (م³/ساعة)'],
        initial: ['${_cap.round()}', '${_flow.round()}']);
    if (r == null) return;
    final c = parseNum(r[0]), f = parseNum(r[1]);
    if (c == null || f == null || c <= 0 || f <= 0) return;
    await LocalDb.setMeta('water_cap', '$c');
    await LocalDb.setMeta('pump_flow', '$f');
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final used = _used;
    final err = Theme.of(context).colorScheme.error;
    return Scaffold(
      appBar: AppBar(title: const Text('الحقول والري'), actions: [
        IconButton(tooltip: 'إعدادات الماء', icon: const Icon(Icons.tune), onPressed: _settings),
      ]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text('حصة الماء هذا الشهر', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        LinearProgressIndicator(value: (used / _cap).clamp(0, 1).toDouble(), minHeight: 10, color: used > _cap * .9 ? err : null),
        Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Text('${used.round()} من ${_cap.round()} م³ (التدفق ${_flow.round()} م³/ساعة)')),
        const Text('الحصة والتدفق قيمتان افتراضيتان، عدّلهما حسب رخصة البئر وقياسك الفعلي.'),
        const SizedBox(height: 12),
        for (final f in _fields)
          Card(
              child: ListTile(
            title: Text(f),
            subtitle: Text(_since(f) == null ? 'لم يُسقَ بعد' : 'آخر ريّ قبل ${_since(f)} يومًا'),
            trailing: FilledButton.tonal(onPressed: () => _irrigate(f), child: const Text('سجّل ريّة')),
          )),
        const SizedBox(height: 8),
        Text('آخر العمليات', style: Theme.of(context).textTheme.titleMedium),
        if (_logs.isEmpty) const Padding(padding: EdgeInsets.all(8), child: Text('لا عمليات بعد.')),
        for (final l in _logs.take(10))
          ListTile(dense: true, title: Text('${l['field_name']}: ${l['hours']} ساعة'), subtitle: Text(l['date'] as String), trailing: Text('${(l['m3'] as num).round()} م³')),
      ]),
    );
  }
}
