import 'package:flutter/material.dart';

import '../core/local_db.dart';
import '../core/util.dart';

class DashboardTab extends StatefulWidget {
  final int pending;
  final int rejected;
  final bool local;
  const DashboardTab({super.key, required this.pending, required this.rejected, this.local = false});
  @override
  State<DashboardTab> createState() => _DashboardTabState();
}

class _DashboardTabState extends State<DashboardTab> {
  late Future<Map<String, dynamic>> _f = _load();

  Future<Map<String, dynamic>> _load() async {
    final animals = (await LocalDb.list('animal')).where((a) => a['status'] == 'active').length;
    final items = await LocalDb.list('stock_item');
    final moves = await LocalDb.list('stock_move');
    final low = <String>[];
    for (final it in items) {
      final use = (it['daily_use'] as num).toDouble();
      if (use <= 0) continue;
      final qty = (it['opening'] as num).toDouble() +
          moves.where((m) => m['item_id'] == it['id']).fold<double>(0, (s, m) => s + (m['delta'] as num));
      final days = qty / use;
      if (days < (it['min_days'] as num)) low.add('${it['name']}: يكفي ${days.toStringAsFixed(0)} أيام');
    }
    final overdue = (await LocalDb.list('task'))
        .where((t) => t['done'] != true && (t['due'] as String).compareTo(today()) < 0)
        .map((t) => t['title'] as String)
        .toList();
    final eggs = (await LocalDb.list('daily_log'))
        .where((l) => l['date'] == today())
        .fold<int>(0, (s, l) => s + ((l['eggs'] as num?) ?? 0).toInt());
    num income = 0, expense = 0;
    for (final t in await LocalDb.list('transaction')) {
      if ((t['date'] as String).startsWith(today().substring(0, 7))) {
        t['type'] == 'in' ? income += (t['amount'] as num) : expense += (t['amount'] as num);
      }
    }
    return {'animals': animals, 'low': low, 'overdue': overdue, 'eggs': eggs, 'net': income - expense};
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return FutureBuilder<Map<String, dynamic>>(
      future: _f,
      builder: (c, s) {
        if (!s.hasData) return const Center(child: CircularProgressIndicator());
        final d = s.data!;
        final alerts = <(String, bool)>[
          for (final x in d['low'] as List<String>) ('مخزون $x', true),
          for (final x in d['overdue'] as List<String>) ('مهمة متأخرة: $x', false),
        ];
        return RefreshIndicator(
          onRefresh: () async => setState(() => _f = _load()),
          child: ListView(padding: const EdgeInsets.all(16), children: [
            Row(children: [
              Expanded(child: _Kpi('رؤوس نشطة', '${d['animals']}')),
              const SizedBox(width: 8),
              Expanded(child: widget.local
                  ? _Kpi('بيض اليوم', '${d['eggs']}')
                  : _Kpi('بانتظار المزامنة', '${widget.pending}')),
            ]),
            Row(children: [
              Expanded(child: _Kpi('صافي الشهر (دج)', '${(d['net'] as num).round()}')),
              const SizedBox(width: 8),
              Expanded(child: widget.local ? const SizedBox.shrink() : _Kpi('بيض اليوم', '${d['eggs']}')),
            ]),
            if (widget.rejected > 0)
              Card(
                  color: cs.errorContainer,
                  child: ListTile(
                      leading: const Icon(Icons.error_outline),
                      title: Text('${widget.rejected} سجلات رفضها الخادم (صلاحية أو رقم مكرر)'))),
            const SizedBox(height: 16),
            Text('التنبيهات', style: Theme.of(context).textTheme.titleMedium),
            if (alerts.isEmpty) const Padding(padding: EdgeInsets.all(8), child: Text('لا تنبيهات الآن.')),
            for (final a in alerts)
              Card(
                  color: a.$2 ? cs.errorContainer : cs.tertiaryContainer,
                  child: ListTile(title: Text(a.$1))),
          ]),
        );
      },
    );
  }
}

class _Kpi extends StatelessWidget {
  final String label;
  final String value;
  const _Kpi(this.label, this.value);
  @override
  Widget build(BuildContext context) => Card(
      child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: Theme.of(context).textTheme.labelMedium),
            Text(value, style: Theme.of(context).textTheme.headlineMedium),
          ])));
}
