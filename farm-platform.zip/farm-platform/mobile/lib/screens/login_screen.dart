import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/local_db.dart';

class LoginScreen extends StatefulWidget {
  final VoidCallback onDone;
  const LoginScreen({super.key, required this.onDone});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _email = TextEditingController();
  final _pw = TextEditingController();
  String? _err;
  bool _busy = false;

  Future<void> _submit() async {
    setState(() {
      _busy = true;
      _err = null;
    });
    try {
      await Api.login(_email.text, _pw.text);
      final email = _email.text.trim().toLowerCase();
      // نحافظ على التعديلات غير المزامنة إن عاد نفس المستعمل، ونمسح بيانات غيره
      final prev = await LocalDb.meta('email');
      if (prev != email || await LocalDb.isLocal()) await LocalDb.wipe();
      await LocalDb.setMeta('email', email);
      await LocalDb.setMeta('mode', 'server');
      widget.onDone();
    } on ApiException catch (e) {
      setState(() => _err = e.message);
    } catch (_) {
      setState(() => _err = 'تعذّر الاتصال بالخادم. تحقق من الإنترنت');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _local() async {
    setState(() => _busy = true);
    await LocalDb.wipe();
    await LocalDb.setMeta('mode', 'local');
    await LocalDb.seedDefaults();
    widget.onDone();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 400),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Text('تسيير المزرعة', style: Theme.of(context).textTheme.headlineMedium),
                const SizedBox(height: 4),
                const Text('يعمل التطبيق بلا إنترنت. اختر الاستعمال المحلي الآن، أو سجّل الدخول بحساب منصة الويب للمزامنة.'),
                const SizedBox(height: 24),
                FilledButton.icon(
                    onPressed: _busy ? null : _local,
                    icon: const Icon(Icons.phone_android),
                    label: const Text('استعمال محلي بدون حساب')),
                const SizedBox(height: 28),
                const Divider(),
                const SizedBox(height: 12),
                TextField(
                    controller: _email,
                    keyboardType: TextInputType.emailAddress,
                    autofillHints: const [AutofillHints.username],
                    decoration: const InputDecoration(labelText: 'البريد الإلكتروني')),
                const SizedBox(height: 12),
                TextField(
                    controller: _pw,
                    obscureText: true,
                    autofillHints: const [AutofillHints.password],
                    decoration: const InputDecoration(labelText: 'كلمة المرور')),
                if (_err != null)
                  Padding(
                      padding: const EdgeInsets.only(top: 12),
                      child: Text(_err!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
                const SizedBox(height: 16),
                OutlinedButton(
                    onPressed: _busy ? null : _submit,
                    child: Text(_busy ? 'جارٍ الدخول...' : 'دخول بحساب المنصة')),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
