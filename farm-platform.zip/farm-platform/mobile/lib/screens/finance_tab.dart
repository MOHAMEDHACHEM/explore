import 'package:flutter/material.dart';

import '../core/local_db.dart';
import '../core/util.dart';

class FinanceTab extends StatefulWidget {
  final VoidCallback onChanged;
  const FinanceTab({super.key, required this.onChanged});
  @override
  State<FinanceTab> createState() => _FinanceTabState();
}

class _FinanceTabState extends State<FinanceTab> {
  List<Map<String, dynamic>> _tx = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final t = await LocalDb.list('transaction');
    t.sort((a, b) => (b['date'] as String).compareTo(a['date'] as String));
    if (mounted) setState(() => _tx = t);
  }

  Future<void> _add() async {
    final cat = TextEditingController();
    final amt = TextEditingController();
    var type = 'out';
    final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => StatefulBuilder(
            builder: (ctx, set) => AlertDialog(
                  title: const Text('قيد جديد'),
                  content: Column(mainAxisSize: MainAxisSize.min, children: [
                    SegmentedButton<String>(
                        segments: const [
                          ButtonSegment(value: 'in', label: Text('إيراد')),
                          ButtonSegment(value: 'out', label: Text('مصروف')),
                        ],
                        selected: {type},
                        onSelectionChanged: (s) => set(() => type = s.first)),
                    TextField(controller: cat, decoration: const InputDecoration(labelText: 'البند: علف، أجور، بيع...')),
                    TextField(
                        controller: amt,
                        keyboardType: const TextInputType.numberWithOptions(decimal: true),
                        decoration: const InputDecoration(labelText: 'المبلغ (دج)')),
                  ]),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
                    FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('سجّل')),
                  ],
                )));
    final a = parseNum(amt.text);
    if (ok != true || cat.text.trim().isEmpty || a == null || a <= 0) return;
    await LocalDb.save('transaction', {'date': today(), 'type': type, 'category': cat.text.trim(), 'amount': a, 'note': ''});
    widget.onChanged();
    await _load();
  }

  String _f(num n) => n.round().toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ' ');

  @override
  Widget build(BuildContext context) {
    final month = today().substring(0, 7);
    num inc = 0, out = 0;
    for (final t in _tx) {
      if ((t['date'] as String).startsWith(month)) {
        (t['type'] == 'in') ? inc += (t['amount'] as num) : out += (t['amount'] as num);
      }
    }
    final err = Theme.of(context).colorScheme.error;
    return Scaffold(
      body: ListView(children: [
        Padding(
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              Expanded(child: _Box('إيراد الشهر', _f(inc))),
              const SizedBox(width: 8),
              Expanded(child: _Box('مصاريف الشهر', _f(out))),
              const SizedBox(width: 8),
              Expanded(child: _Box('الصافي', _f(inc - out))),
            ])),
        if (_tx.isEmpty) const Padding(padding: EdgeInsets.all(24), child: Center(child: Text('لا قيود بعد. اضغط + لإضافة أول قيد.'))),
        for (final t in _tx.take(50))
          ListTile(
            title: Text(t['category'] as String),
            subtitle: Text(t['date'] as String),
            trailing: Text('${t['type'] == 'out' ? '−' : '+'}${_f(t['amount'] as num)}',
                style: TextStyle(color: t['type'] == 'out' ? err : null, fontWeight: FontWeight.bold)),
          ),
      ]),
      floatingActionButton: FloatingActionButton(onPressed: _add, tooltip: 'قيد جديد', child: const Icon(Icons.add)),
    );
  }
}

class _Box extends StatelessWidget {
  final String label;
  final String value;
  const _Box(this.label, this.value);
  @override
  Widget build(BuildContext context) => Card(
      child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: Theme.of(context).textTheme.labelSmall),
            Text(value, style: Theme.of(context).textTheme.titleMedium),
          ])));
}
