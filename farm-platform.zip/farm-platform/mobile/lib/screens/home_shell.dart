import 'dart:async';

import 'package:flutter/material.dart';

import '../core/api.dart';
import '../core/local_db.dart';
import '../core/sync.dart';
import 'animals_tab.dart';
import 'dashboard_tab.dart';
import 'more_tab.dart';
import 'poultry_tab.dart';
import 'stock_tab.dart';

class HomeShell extends StatefulWidget {
  final VoidCallback onLogout;
  const HomeShell({super.key, required this.onLogout});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _tab = 0;
  int _version = 0; // يتغير بعد كل مزامنة لإعادة تحميل التبويب
  int _pending = 0;
  int _rejected = 0;
  bool _syncing = false;
  bool _local = true;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final local = await LocalDb.isLocal();
    if (!mounted) return;
    setState(() => _local = local);
    await _refreshCounts();
    if (!local) {
      _sync();
      _timer = Timer.periodic(const Duration(minutes: 2), (_) => _sync());
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _refreshCounts() async {
    final p = await LocalDb.pendingCount();
    final r = await LocalDb.rejectedCount();
    if (mounted) setState(() => (_pending, _rejected) = (p, r));
  }

  Future<void> _sync({bool manual = false}) async {
    if (_syncing) return;
    setState(() => _syncing = true);
    final res = await syncNow();
    await _refreshCounts();
    if (!mounted) return;
    setState(() {
      _syncing = false;
      if (res.ok) _version++;
    });
    if (!res.ok && res.error != null && res.error!.contains('سجّل الدخول')) {
      widget.onLogout();
    } else if (manual || !res.ok) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(res.ok
              ? (res.rejected > 0 ? 'رُفض ${res.rejected} سجلات. راجع البيانات' : 'تمت المزامنة')
              : res.error ?? 'تعذّرت المزامنة')));
    }
  }

  void _changed() => _refreshCounts();

  Future<void> _logout() async {
    final warn = _local
        ? 'سيُحذف كل ما سجّلته على هذا الهاتف نهائيًا لأنه محلي فقط.'
        : (_pending > 0 ? 'يوجد $_pending تعديلات لم تُزامَن وستُفقد.' : 'سيُغلق حسابك على هذا الهاتف.');
    final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
              title: const Text('تأكيد الخروج'),
              content: Text(warn),
              actions: [
                TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
                FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('خروج')),
              ],
            ));
    if (ok != true) return;
    await Api.logout();
    await LocalDb.wipe();
    widget.onLogout();
  }

  @override
  Widget build(BuildContext context) {
    final tabs = <Widget>[
      DashboardTab(key: ValueKey('d$_version'), pending: _pending, rejected: _rejected, local: _local),
      AnimalsTab(key: ValueKey('a$_version'), onChanged: _changed),
      PoultryTab(key: ValueKey('p$_version'), onChanged: _changed),
      StockTab(key: ValueKey('s$_version'), onChanged: _changed),
      MoreTab(key: ValueKey('m$_version'), onChanged: _changed),
    ];
    return Scaffold(
      appBar: AppBar(
        title: Text(_local ? 'تسيير المزرعة (محلي)' : 'تسيير المزرعة'),
        actions: [
          if (!_local && _pending > 0)
            Center(
                child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: Text('$_pending بانتظار المزامنة', style: Theme.of(context).textTheme.labelSmall))),
          if (!_local)
            _syncing
                ? const Padding(
                    padding: EdgeInsets.all(14),
                    child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)))
                : IconButton(
                    tooltip: 'مزامنة الآن',
                    icon: const Icon(Icons.sync),
                    onPressed: () => _sync(manual: true)),
          IconButton(tooltip: 'خروج', icon: const Icon(Icons.logout), onPressed: _logout),
        ],
      ),
      body: tabs[_tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.pets_outlined), label: 'القطيع'),
          NavigationDestination(icon: Icon(Icons.egg_alt_outlined), label: 'الدواجن'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), label: 'المخزون'),
          NavigationDestination(icon: Icon(Icons.more_horiz), label: 'المزيد'),
        ],
      ),
    );
  }
}
