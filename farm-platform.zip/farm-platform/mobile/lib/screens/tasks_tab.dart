import 'package:flutter/material.dart';

import '../core/local_db.dart';
import '../core/util.dart';

class TasksTab extends StatefulWidget {
  final VoidCallback onChanged;
  const TasksTab({super.key, required this.onChanged});
  @override
  State<TasksTab> createState() => _TasksTabState();
}

class _TasksTabState extends State<TasksTab> {
  List<Map<String, dynamic>> _tasks = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final t = await LocalDb.list('task');
    t.sort((a, b) {
      final d = (a['done'] == true ? 1 : 0) - (b['done'] == true ? 1 : 0);
      return d != 0 ? d : (a['due'] as String).compareTo(b['due'] as String);
    });
    if (mounted) setState(() => _tasks = t);
  }

  Future<void> _toggle(Map<String, dynamic> t) async {
    await LocalDb.save('task', {...t, 'done': !(t['done'] == true)});
    widget.onChanged();
    await _load();
  }

  Future<void> _add() async {
    final c = TextEditingController();
    final title = await showDialog<String>(
        context: context,
        builder: (ctx) => AlertDialog(
              title: const Text('مهمة جديدة'),
              content: TextField(controller: c, autofocus: true, decoration: const InputDecoration(hintText: 'مثال: تلقيح الحملان')),
              actions: [
                TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
                FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('التالي')),
              ],
            ));
    if (title == null || title.isEmpty || !mounted) return;
    final d = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime.now().subtract(const Duration(days: 30)),
        lastDate: DateTime.now().add(const Duration(days: 730)));
    if (d == null) return;
    await LocalDb.save('task', {'title': title, 'due': d.toIso8601String().substring(0, 10), 'done': false});
    widget.onChanged();
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final err = Theme.of(context).colorScheme.error;
    return Scaffold(
      body: _tasks.isEmpty
          ? const Center(child: Text('لا مهام. اضغط + لإضافة أول مهمة.'))
          : ListView.builder(
              itemCount: _tasks.length,
              itemBuilder: (c, i) {
                final t = _tasks[i];
                final done = t['done'] == true;
                final late = !done && (t['due'] as String).compareTo(today()) < 0;
                return CheckboxListTile(
                  value: done,
                  onChanged: (_) => _toggle(t),
                  title: Text(t['title'] as String, style: TextStyle(decoration: done ? TextDecoration.lineThrough : null)),
                  subtitle: Text(t['due'] as String, style: TextStyle(color: late ? err : null)),
                );
              }),
      floatingActionButton: FloatingActionButton(onPressed: _add, tooltip: 'مهمة جديدة', child: const Icon(Icons.add)),
    );
  }
}
