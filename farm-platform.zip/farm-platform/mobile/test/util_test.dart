import 'package:flutter_test/flutter_test.dart';
import 'package:farm_app/core/util.dart';

void main() {
  test('الزيادة اليومية', () {
    final w = [
      {'date': '2026-01-01', 'kg': 24.0},
      {'date': '2026-01-31', 'kg': 33.0},
    ];
    expect(adgGrams(w), closeTo(300, 0.001));
    expect(adgGrams([w.first]), isNull);
  });
}
