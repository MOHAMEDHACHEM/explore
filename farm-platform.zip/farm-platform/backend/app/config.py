import os

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./farm.db")
SECRET_KEY = os.getenv("SECRET_KEY", "dev-only-change-me")
TOKEN_MINUTES = int(os.getenv("TOKEN_MINUTES", str(60 * 24 * 7)))
CORS_ORIGINS = [o for o in os.getenv("CORS_ORIGINS", "").split(",") if o]
# الحد الأقصى للرؤوس النشطة في كل باقة (يُطبَّق عند إضافة رأس جديد)
PLAN_LIMITS = {"free": 100, "basic": 1000, "pro": 100000}
