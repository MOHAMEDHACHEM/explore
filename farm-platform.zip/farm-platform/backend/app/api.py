from datetime import date, timedelta
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, EmailStr, Field, ValidationError
from sqlalchemy import and_, func, or_, select
from sqlalchemy.orm import Session

from .config import PLAN_LIMITS
from .db import get_db
from .models import (Animal, DailyLog, Group, HealthEvent, StockItem, StockMove, Task,
                     Tenant, Transaction, User, now_ms, uid)
from .schemas import DELETE_ROLES, ENTITIES, Date
from .security import check_pw, hash_pw, make_token, read_token

router = APIRouter(prefix="/api")
bearer = HTTPBearer(auto_error=False)


# ---------------------------------------------------------------- المصادقة
class Ctx:
    def __init__(self, user: User, tenant: Tenant):
        self.user, self.tenant = user, tenant


def current(creds: HTTPAuthorizationCredentials = Depends(bearer),
            db: Session = Depends(get_db)) -> Ctx:
    if not creds:
        raise HTTPException(401, "مطلوب تسجيل الدخول")
    try:
        payload = read_token(creds.credentials)
    except Exception:
        raise HTTPException(401, "الجلسة غير صالحة أو منتهية")
    user = db.get(User, payload.get("sub"))
    if not user or not user.active:
        raise HTTPException(401, "الحساب غير مفعّل")
    return Ctx(user, db.get(Tenant, user.tenant_id))


def roles(*allowed: str):
    def dep(ctx: Ctx = Depends(current)) -> Ctx:
        if ctx.user.role not in allowed:
            raise HTTPException(403, "ليست لديك صلاحية لهذا الإجراء")
        return ctx
    return dep


class RegisterIn(BaseModel):
    farm_name: str = Field(min_length=2, max_length=120)
    name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class LoginIn(BaseModel):
    email: EmailStr
    password: str


class UserIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    role: Literal["supervisor", "worker", "vet"]


def _session(user: User, tenant: Tenant) -> dict:
    return {"token": make_token(user.id, user.tenant_id, user.role),
            "user": {"id": user.id, "name": user.name, "role": user.role},
            "tenant": {"id": tenant.id, "name": tenant.name, "plan": tenant.plan}}


def _seed_defaults(db: Session, tenant_id: str, user_id: str) -> None:
    ts = now_ms()
    base = dict(tenant_id=tenant_id, client_ts=ts, updated_at=ts, created_by=user_id)
    for name, kind, breed in [("أولاد جلال", "sheep", "أولاد جلال"), ("الرمبي", "sheep", "الرمبي"),
                              ("الحمراء", "sheep", "الحمراء"), ("الماعز", "goat", ""),
                              ("دجاج البياض", "layers", ""), ("دجاج اللحم", "broilers", ""),
                              ("دجاج الزينة", "ornamental", "")]:
        db.add(Group(name=name, kind=kind, breed=breed, **base))
    for name, use in [("شعير", 6), ("فصة مجففة", 2.5), ("علف البياض", 1.2), ("علف اللحم", 8)]:
        db.add(StockItem(name=name, daily_use=use, **base))


@router.post("/auth/register")
def register(body: RegisterIn, db: Session = Depends(get_db)):
    email = body.email.lower()
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(409, "البريد الإلكتروني مسجّل مسبقًا")
    tenant = Tenant(name=body.farm_name)
    user = User(tenant_id=tenant.id, email=email, name=body.name, role="owner",
                pw_hash=hash_pw(body.password))
    tenant.id = tenant.id or uid()
    db.add(tenant)
    db.flush()
    user.tenant_id = tenant.id
    db.add(user)
    db.flush()
    _seed_defaults(db, tenant.id, user.id)
    db.commit()
    return _session(user, tenant)


@router.post("/auth/login")
def login(body: LoginIn, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == body.email.lower()))
    if not user or not user.active or not check_pw(body.password, user.pw_hash):
        raise HTTPException(401, "البريد أو كلمة المرور غير صحيحة")
    return _session(user, db.get(Tenant, user.tenant_id))


@router.get("/me")
def me(ctx: Ctx = Depends(current)):
    return {"user": {"id": ctx.user.id, "name": ctx.user.name, "role": ctx.user.role},
            "tenant": {"id": ctx.tenant.id, "name": ctx.tenant.name, "plan": ctx.tenant.plan,
                       "animal_limit": PLAN_LIMITS[ctx.tenant.plan]}}


@router.get("/users")
def list_users(ctx: Ctx = Depends(roles("owner", "supervisor")), db: Session = Depends(get_db)):
    rows = db.scalars(select(User).where(User.tenant_id == ctx.tenant.id))
    return [{"id": u.id, "name": u.name, "email": u.email, "role": u.role, "active": u.active}
            for u in rows]


@router.post("/users")
def create_user(body: UserIn, ctx: Ctx = Depends(roles("owner")), db: Session = Depends(get_db)):
    email = body.email.lower()
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(409, "البريد الإلكتروني مسجّل مسبقًا")
    u = User(tenant_id=ctx.tenant.id, email=email, name=body.name, role=body.role,
             pw_hash=hash_pw(body.password))
    db.add(u)
    db.commit()
    return {"id": u.id, "name": u.name, "email": u.email, "role": u.role, "active": True}


# ---------------------------------------------------------------- الكيانات
def to_dict(row) -> dict:
    return {c.name: getattr(row, c.name) for c in row.__table__.columns if c.name != "tenant_id"}


def _check_animal(db: Session, ctx: Ctx, d: dict, is_new: bool) -> None:
    dup = db.scalar(select(func.count()).select_from(Animal).where(
        Animal.tenant_id == ctx.tenant.id, Animal.tag == d["tag"], Animal.id != d["id"],
        Animal.deleted == False))  # noqa: E712
    if dup:
        raise HTTPException(409, "رقم التعريف مستعمل لرأس آخر")
    if is_new and not d["deleted"]:
        active = db.scalar(select(func.count()).select_from(Animal).where(
            Animal.tenant_id == ctx.tenant.id, Animal.deleted == False,  # noqa: E712
            Animal.status == "active"))
        if active >= PLAN_LIMITS[ctx.tenant.plan]:
            raise HTTPException(402, "بلغت الحد الأقصى للرؤوس في باقتك. رقِّ الباقة للمتابعة")


def withdrawal_block(db: Session, tenant_id: str, a: Animal, on: date):
    """يعيد (تاريخ السماح، الدواء) إن كانت مدة سحب جارية للرأس أو لقطيعه، وإلا None."""
    cond = [and_(HealthEvent.target_type == "animal", HealthEvent.target_id == a.id)]
    if a.group_id:
        cond.append(and_(HealthEvent.target_type == "group", HealthEvent.target_id == a.group_id))
    events = db.scalars(select(HealthEvent).where(
        HealthEvent.tenant_id == tenant_id, HealthEvent.deleted == False,  # noqa: E712
        HealthEvent.withdrawal_days > 0, or_(*cond))).all()
    blocking = [(date.fromisoformat(e.date) + timedelta(days=e.withdrawal_days), e) for e in events]
    blocking = [(u, e) for u, e in blocking if u > on]
    if not blocking:
        return None
    until, ev = max(blocking, key=lambda x: x[0])
    return until, ev.product or "علاج"


def upsert(db: Session, ctx: Ctx, name: str, data: dict, sync: bool = False):
    Model, Schema, wroles, _ = ENTITIES[name]
    if ctx.user.role not in wroles:
        raise HTTPException(403, "ليست لديك صلاحية لهذا الإجراء")
    try:
        d = Schema.model_validate(data).model_dump()
    except ValidationError as e:
        raise HTTPException(422, "; ".join(f"{'.'.join(map(str, x['loc']))}: {x['msg']}"
                                           for x in e.errors()))
    if d["deleted"] and ctx.user.role not in DELETE_ROLES:
        raise HTTPException(403, "الحذف للمالك والمشرف فقط")
    cts = d.pop("client_ts") or now_ms()
    row = db.get(Model, d["id"])
    if row is not None and row.tenant_id != ctx.tenant.id:
        raise HTTPException(409, "معرّف مستعمل")
    if row is not None and sync and row.client_ts >= cts:
        return row, False  # نسخة الخادم أحدث: تُسحب إلى العميل
    if name == "animal":
        _check_animal(db, ctx, d, is_new=row is None)
        if row is not None and row.status != "sold" and d["status"] == "sold":
            blk = withdrawal_block(db, ctx.tenant.id, row, date.today())
            if blk:
                raise HTTPException(409, f"مدة السحب جارية ({blk[1]}). يُسمح بالبيع بدءًا من {blk[0].isoformat()}")
    if row is None:
        row = Model(id=d["id"], tenant_id=ctx.tenant.id, created_by=ctx.user.id)
        db.add(row)
    for k, v in d.items():
        if k != "id":
            setattr(row, k, v)
    row.client_ts, row.updated_at = cts, now_ms()
    db.flush()
    return row, True


def _make_routes(name: str) -> None:
    Model, Schema, wroles, slug = ENTITIES[name]

    @router.get(f"/{slug}", name=f"list_{name}")
    def list_(since: int = 0, ctx: Ctx = Depends(current), db: Session = Depends(get_db)):
        q = select(Model).where(Model.tenant_id == ctx.tenant.id, Model.updated_at >= since)
        if since == 0:
            q = q.where(Model.deleted == False)  # noqa: E712
        return [to_dict(r) for r in db.scalars(q)]

    @router.post(f"/{slug}", name=f"create_{name}")
    def create(body: Schema, ctx: Ctx = Depends(current), db: Session = Depends(get_db)):
        row, _ = upsert(db, ctx, name, body.model_dump())
        db.commit()
        return to_dict(row)

    @router.put(f"/{slug}/{{rid}}", name=f"update_{name}")
    def update(rid: str, body: Schema, ctx: Ctx = Depends(current), db: Session = Depends(get_db)):
        old = db.get(Model, rid)
        if not old or old.tenant_id != ctx.tenant.id:
            raise HTTPException(404, "غير موجود")
        row, _ = upsert(db, ctx, name, {**body.model_dump(), "id": rid})
        db.commit()
        return to_dict(row)

    @router.delete(f"/{slug}/{{rid}}", name=f"delete_{name}")
    def delete(rid: str, ctx: Ctx = Depends(roles(*DELETE_ROLES)), db: Session = Depends(get_db)):
        row = db.get(Model, rid)
        if not row or row.tenant_id != ctx.tenant.id:
            raise HTTPException(404, "غير موجود")
        row.deleted, row.client_ts, row.updated_at = True, now_ms(), now_ms()
        db.commit()
        return {"ok": True}


for _n in ENTITIES:
    _make_routes(_n)


# ---------------------------------------------------------------- المزامنة
class SyncIn(BaseModel):
    last_pulled: int = 0
    changes: dict[str, list[dict]] = {}


@router.post("/sync")
def sync(body: SyncIn, ctx: Ctx = Depends(current), db: Session = Depends(get_db)):
    """دفع تعديلات العميل (آخر تعديل يفوز حسب client_ts) ثم سحب ما تغيّر في الخادم."""
    rejected = []
    for name, recs in body.changes.items():
        if name not in ENTITIES:
            continue
        for r in recs:
            try:
                upsert(db, ctx, name, r, sync=True)
            except HTTPException as e:
                rejected.append({"entity": name, "id": r.get("id"), "status": e.status_code,
                                 "reason": e.detail})
    db.commit()
    server_time = now_ms()
    out = {}
    for name, (Model, _, _, _) in ENTITIES.items():
        rows = db.scalars(select(Model).where(Model.tenant_id == ctx.tenant.id,
                                              Model.updated_at >= body.last_pulled))
        out[name] = [to_dict(r) for r in rows]
    return {"server_time": server_time, "changes": out, "rejected": rejected}


# ---------------------------------------------------------------- قواعد العمل
class SellIn(BaseModel):
    price: float = Field(gt=0)
    date: Date | None = None


@router.post("/animals/{aid}/sell")
def sell(aid: str, body: SellIn, ctx: Ctx = Depends(roles("owner", "supervisor")),
         db: Session = Depends(get_db)):
    """بيع رأس مع منع البيع أثناء مدة السحب الدوائي وتسجيل الإيراد تلقائيًا."""
    a = db.get(Animal, aid)
    if not a or a.tenant_id != ctx.tenant.id or a.deleted:
        raise HTTPException(404, "غير موجود")
    if a.status != "active":
        raise HTTPException(409, "الرأس غير نشط")
    on = date.fromisoformat(body.date) if body.date else date.today()
    blk = withdrawal_block(db, ctx.tenant.id, a, on)
    if blk:
        raise HTTPException(409, f"مدة السحب جارية ({blk[1]}). يُسمح بالبيع بدءًا من {blk[0].isoformat()}")
    ts = now_ms()
    a.status, a.client_ts, a.updated_at = "sold", ts, ts
    tx = Transaction(tenant_id=ctx.tenant.id, date=on.isoformat(), type="in", category="بيع " + a.tag,
                     amount=body.price, client_ts=ts, updated_at=ts, created_by=ctx.user.id)
    db.add(tx)
    db.commit()
    return {"ok": True, "animal": to_dict(a), "transaction": to_dict(tx)}


@router.get("/dashboard")
def dashboard(ctx: Ctx = Depends(current), db: Session = Depends(get_db)):
    tid, today = ctx.tenant.id, date.today()
    live = lambda M: (M.tenant_id == tid, M.deleted == False)  # noqa: E712,E731
    animals = db.scalar(select(func.count()).select_from(Animal).where(
        *live(Animal), Animal.status == "active"))
    groups = db.scalars(select(Group).where(*live(Group))).all()
    poultry = {k: sum(g.qty for g in groups if g.kind == k) for k in ("layers", "broilers", "ornamental")}
    sums = dict(db.execute(select(StockMove.item_id, func.sum(StockMove.delta))
                           .where(*live(StockMove)).group_by(StockMove.item_id)).all())
    stock = []
    for it in db.scalars(select(StockItem).where(*live(StockItem))):
        qty = it.opening + (sums.get(it.id) or 0)
        days = qty / it.daily_use if it.daily_use > 0 else None
        stock.append({"id": it.id, "name": it.name, "unit": it.unit, "qty": round(qty, 2),
                      "days": None if days is None else round(days, 1),
                      "low": days is not None and days < it.min_days})
    overdue = db.scalar(select(func.count()).select_from(Task).where(
        *live(Task), Task.done == False, Task.due < today.isoformat()))  # noqa: E712
    month = today.isoformat()[:7]
    money = dict(db.execute(select(Transaction.type, func.sum(Transaction.amount)).where(
        *live(Transaction), Transaction.date.like(month + "%")).group_by(Transaction.type)).all())
    eggs = db.scalar(select(func.coalesce(func.sum(DailyLog.eggs), 0)).where(
        *live(DailyLog), DailyLog.date == today.isoformat()))
    laying = poultry["layers"]
    return {"animals": animals, "poultry": poultry, "stock": stock, "overdue_tasks": overdue,
            "month": {"income": money.get("in", 0) or 0, "expense": money.get("out", 0) or 0},
            "eggs_today": eggs, "laying_rate": round(eggs / laying, 3) if laying and eggs else None}
