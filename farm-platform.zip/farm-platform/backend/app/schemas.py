from datetime import date as _date
from typing import Annotated, Literal

from pydantic import AfterValidator, BaseModel, ConfigDict, Field

from .models import (Animal, DailyLog, Group, HealthEvent, Irrigation, StockItem,
                     StockMove, Task, Transaction, Weight, uid)


def _iso(v: str) -> str:
    _date.fromisoformat(v)
    return v


Date = Annotated[str, AfterValidator(_iso)]
Id = Annotated[str, Field(min_length=8, max_length=32)]


class Rec(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: Id = Field(default_factory=uid)
    client_ts: int | None = None
    deleted: bool = False


class GroupIn(Rec):
    name: str = Field(min_length=1, max_length=80)
    kind: Literal["sheep", "goat", "layers", "broilers", "ornamental"]
    breed: str = Field(default="", max_length=60)
    qty: int = Field(default=0, ge=0)


class AnimalIn(Rec):
    tag: str = Field(min_length=1, max_length=40)
    group_id: str = ""
    sex: Literal["F", "M"] = "F"
    birth_date: str = ""
    status: Literal["active", "sold", "dead"] = "active"


class WeightIn(Rec):
    animal_id: Id
    date: Date
    kg: float = Field(gt=0, lt=500)


class HealthIn(Rec):
    target_type: Literal["animal", "group"]
    target_id: Id
    kind: Literal["vaccine", "treatment", "deworm"]
    product: str = Field(default="", max_length=80)
    date: Date
    withdrawal_days: int = Field(default=0, ge=0, le=365)
    note: str = Field(default="", max_length=1000)


class StockItemIn(Rec):
    name: str = Field(min_length=1, max_length=80)
    unit: str = Field(default="قنطار", max_length=16)
    opening: float = Field(default=0, ge=0)
    daily_use: float = Field(default=0, ge=0)
    min_days: int = Field(default=10, ge=0)


class StockMoveIn(Rec):
    item_id: Id
    date: Date
    delta: float
    note: str = Field(default="", max_length=200)


class TaskIn(Rec):
    title: str = Field(min_length=1, max_length=200)
    due: Date
    done: bool = False


class TransactionIn(Rec):
    date: Date
    type: Literal["in", "out"]
    category: str = Field(min_length=1, max_length=60)
    amount: float = Field(gt=0)
    note: str = Field(default="", max_length=200)


class IrrigationIn(Rec):
    field_name: str = Field(min_length=1, max_length=80)
    date: Date
    hours: float = Field(gt=0, le=240)
    m3: float = Field(default=0, ge=0)


class DailyLogIn(Rec):
    group_id: Id
    date: Date
    eggs: int = Field(default=0, ge=0)
    deaths: int = Field(default=0, ge=0)
    feed_kg: float = Field(default=0, ge=0)


OWNER_SUP = {"owner", "supervisor"}
FIELD = OWNER_SUP | {"worker"}
DELETE_ROLES = OWNER_SUP

# الاسم: (النموذج، المخطط، الأدوار المسموح لها بالكتابة، مقطع الرابط)
ENTITIES = {
    "group": (Group, GroupIn, OWNER_SUP, "groups"),
    "animal": (Animal, AnimalIn, FIELD, "animals"),
    "weight": (Weight, WeightIn, FIELD | {"vet"}, "weights"),
    "health": (HealthEvent, HealthIn, OWNER_SUP | {"vet"}, "health"),
    "stock_item": (StockItem, StockItemIn, OWNER_SUP, "stock-items"),
    "stock_move": (StockMove, StockMoveIn, FIELD, "stock-moves"),
    "task": (Task, TaskIn, FIELD, "tasks"),
    "transaction": (Transaction, TransactionIn, OWNER_SUP, "transactions"),
    "irrigation": (Irrigation, IrrigationIn, FIELD, "irrigation"),
    "daily_log": (DailyLog, DailyLogIn, FIELD, "daily-logs"),
}
