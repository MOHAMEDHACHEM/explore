import time
import uuid

from sqlalchemy import BigInteger, Boolean, Float, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from .db import Base


def now_ms() -> int:
    return int(time.time() * 1000)


def uid() -> str:
    return uuid.uuid4().hex


class Tenant(Base):
    __tablename__ = "tenants"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=uid)
    name: Mapped[str] = mapped_column(String(120))
    plan: Mapped[str] = mapped_column(String(16), default="free")
    created_at: Mapped[int] = mapped_column(BigInteger, default=now_ms)


class User(Base):
    __tablename__ = "users"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(String(32), index=True)
    email: Mapped[str] = mapped_column(String(160), unique=True)
    name: Mapped[str] = mapped_column(String(120))
    role: Mapped[str] = mapped_column(String(16))  # owner | supervisor | worker | vet
    pw_hash: Mapped[str] = mapped_column(String(200))
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class Sync:
    """أعمدة مشتركة لكل الكيانات القابلة للمزامنة.
    updated_at: وقت الخادم (للسحب)، client_ts: وقت تعديل العميل (لحسم التعارض)."""
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=uid)
    tenant_id: Mapped[str] = mapped_column(String(32), index=True)
    updated_at: Mapped[int] = mapped_column(BigInteger, default=now_ms, index=True)
    client_ts: Mapped[int] = mapped_column(BigInteger, default=0)
    deleted: Mapped[bool] = mapped_column(Boolean, default=False)
    created_by: Mapped[str] = mapped_column(String(32), default="")


class Group(Sync, Base):
    __tablename__ = "groups"
    name: Mapped[str] = mapped_column(String(80))
    kind: Mapped[str] = mapped_column(String(16))  # sheep goat layers broilers ornamental
    breed: Mapped[str] = mapped_column(String(60), default="")
    qty: Mapped[int] = mapped_column(Integer, default=0)  # للدواجن فقط


class Animal(Sync, Base):
    __tablename__ = "animals"
    tag: Mapped[str] = mapped_column(String(40), index=True)
    group_id: Mapped[str] = mapped_column(String(32), default="")
    sex: Mapped[str] = mapped_column(String(1), default="F")
    birth_date: Mapped[str] = mapped_column(String(10), default="")
    status: Mapped[str] = mapped_column(String(10), default="active")  # active sold dead


class Weight(Sync, Base):
    __tablename__ = "weights"
    animal_id: Mapped[str] = mapped_column(String(32), index=True)
    date: Mapped[str] = mapped_column(String(10))
    kg: Mapped[float] = mapped_column(Float)


class HealthEvent(Sync, Base):
    __tablename__ = "health_events"
    target_type: Mapped[str] = mapped_column(String(8))  # animal | group
    target_id: Mapped[str] = mapped_column(String(32), index=True)
    kind: Mapped[str] = mapped_column(String(16))  # vaccine treatment deworm
    product: Mapped[str] = mapped_column(String(80), default="")
    date: Mapped[str] = mapped_column(String(10))
    withdrawal_days: Mapped[int] = mapped_column(Integer, default=0)
    note: Mapped[str] = mapped_column(Text, default="")


class StockItem(Sync, Base):
    __tablename__ = "stock_items"
    name: Mapped[str] = mapped_column(String(80))
    unit: Mapped[str] = mapped_column(String(16), default="قنطار")
    opening: Mapped[float] = mapped_column(Float, default=0)
    daily_use: Mapped[float] = mapped_column(Float, default=0)
    min_days: Mapped[int] = mapped_column(Integer, default=10)


class StockMove(Sync, Base):
    __tablename__ = "stock_moves"
    item_id: Mapped[str] = mapped_column(String(32), index=True)
    date: Mapped[str] = mapped_column(String(10))
    delta: Mapped[float] = mapped_column(Float)  # موجب = استلام، سالب = صرف
    note: Mapped[str] = mapped_column(String(200), default="")


class Task(Sync, Base):
    __tablename__ = "tasks"
    title: Mapped[str] = mapped_column(String(200))
    due: Mapped[str] = mapped_column(String(10))
    done: Mapped[bool] = mapped_column(Boolean, default=False)


class Transaction(Sync, Base):
    __tablename__ = "transactions"
    date: Mapped[str] = mapped_column(String(10), index=True)
    type: Mapped[str] = mapped_column(String(3))  # in | out
    category: Mapped[str] = mapped_column(String(60))
    amount: Mapped[float] = mapped_column(Float)
    note: Mapped[str] = mapped_column(String(200), default="")


class Irrigation(Sync, Base):
    __tablename__ = "irrigation"
    field_name: Mapped[str] = mapped_column(String(80))
    date: Mapped[str] = mapped_column(String(10))
    hours: Mapped[float] = mapped_column(Float)
    m3: Mapped[float] = mapped_column(Float, default=0)


class DailyLog(Sync, Base):
    __tablename__ = "daily_logs"
    group_id: Mapped[str] = mapped_column(String(32), index=True)
    date: Mapped[str] = mapped_column(String(10), index=True)
    eggs: Mapped[int] = mapped_column(Integer, default=0)
    deaths: Mapped[int] = mapped_column(Integer, default=0)
    feed_kg: Mapped[float] = mapped_column(Float, default=0)
