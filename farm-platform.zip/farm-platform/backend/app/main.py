from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles

from .api import router
from .config import CORS_ORIGINS
from .db import Base, engine

app = FastAPI(title="Farm SaaS", version="1.0.0")
Base.metadata.create_all(engine)  # للإنتاج: استعمل Alembic للترحيلات
if CORS_ORIGINS:
    app.add_middleware(CORSMiddleware, allow_origins=CORS_ORIGINS, allow_methods=["*"],
                       allow_headers=["*"])
app.include_router(router)


@app.get("/healthz")
def healthz():
    return {"ok": True}


@app.get("/", include_in_schema=False)
def root():
    return RedirectResponse("/app/")


_web = Path(__file__).resolve().parents[2] / "web"
if _web.exists():
    app.mount("/app", StaticFiles(directory=_web, html=True), name="web")
