import hashlib
import hmac
import os
import time

import jwt

from .config import SECRET_KEY, TOKEN_MINUTES

_ITER = 200_000


def hash_pw(pw: str) -> str:
    salt = os.urandom(16)
    h = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, _ITER)
    return f"{salt.hex()}${h.hex()}"


def check_pw(pw: str, stored: str) -> bool:
    salt, h = stored.split("$")
    calc = hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), _ITER).hex()
    return hmac.compare_digest(calc, h)


def make_token(user_id: str, tenant_id: str, role: str) -> str:
    payload = {"sub": user_id, "tid": tenant_id, "role": role,
               "exp": int(time.time()) + TOKEN_MINUTES * 60}
    return jwt.encode(payload, SECRET_KEY, algorithm="HS256")


def read_token(token: str) -> dict:
    return jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
