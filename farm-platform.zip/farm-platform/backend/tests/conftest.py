import os
import tempfile

_f = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
os.environ["DATABASE_URL"] = f"sqlite:///{_f.name}"

import pytest
from fastapi.testclient import TestClient

from app.main import app


@pytest.fixture(scope="session")
def client():
    with TestClient(app) as c:
        yield c


_n = [0]


def register(client, farm="مزرعة"):
    _n[0] += 1
    r = client.post("/api/auth/register", json={
        "farm_name": farm, "name": "المالك", "email": f"owner{_n[0]}@farm.dz",
        "password": "password123"})
    assert r.status_code == 200, r.text
    return {"Authorization": "Bearer " + r.json()["token"]}, r.json()
