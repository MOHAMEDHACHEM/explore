from datetime import date, timedelta

from app.config import PLAN_LIMITS
from tests.conftest import register

TODAY = date.today().isoformat()


def mk_animal(c, h, tag, **kw):
    r = c.post("/api/animals", headers=h, json={"tag": tag, **kw})
    assert r.status_code == 200, r.text
    return r.json()


def test_register_seeds_defaults_and_login(client):
    h, s = register(client)
    groups = client.get("/api/groups", headers=h).json()
    assert len(groups) == 7 and {g["kind"] for g in groups} >= {"sheep", "layers"}
    assert len(client.get("/api/stock-items", headers=h).json()) == 4
    bad = client.post("/api/auth/login", json={"email": "x@y.dz", "password": "nope-nope"})
    assert bad.status_code == 401
    assert client.get("/api/animals").status_code == 401


def test_tenant_isolation(client):
    ha, _ = register(client, "مزرعة أ")
    hb, _ = register(client, "مزرعة ب")
    a = mk_animal(client, ha, "OJ-1")
    assert client.get("/api/animals", headers=hb).json() == []
    assert client.put(f"/api/animals/{a['id']}", headers=hb, json={"tag": "HACK"}).status_code == 404
    assert client.delete(f"/api/animals/{a['id']}", headers=hb).status_code == 404
    # مزامنة B بنفس المعرّف لا تمس بيانات A
    r = client.post("/api/sync", headers=hb, json={"changes": {"animal": [{"id": a["id"], "tag": "HACK"}]}}).json()
    assert r["rejected"] and client.get("/api/animals", headers=ha).json()[0]["tag"] == "OJ-1"


def test_roles(client):
    ho, _ = register(client)
    u = client.post("/api/users", headers=ho, json={"name": "عامل", "email": "w@farm.dz",
                                                    "password": "password123", "role": "worker"})
    assert u.status_code == 200
    hw = {"Authorization": "Bearer " + client.post("/api/auth/login", json={
        "email": "w@farm.dz", "password": "password123"}).json()["token"]}
    a = mk_animal(client, hw, "W-1")
    tx = {"date": TODAY, "type": "in", "category": "بيع", "amount": 1000}
    assert client.post("/api/transactions", headers=hw, json=tx).status_code == 403
    assert client.delete(f"/api/animals/{a['id']}", headers=hw).status_code == 403
    assert client.post("/api/users", headers=hw, json={"name": "x y", "email": "z@z.dz",
                                                       "password": "password123", "role": "vet"}).status_code == 403
    assert client.post("/api/transactions", headers=ho, json=tx).status_code == 200
    assert client.delete(f"/api/animals/{a['id']}", headers=ho).status_code == 200


def test_withdrawal_period_blocks_sale(client):
    h, _ = register(client)
    a = mk_animal(client, h, "S-1")
    ev = {"target_type": "animal", "target_id": a["id"], "kind": "treatment",
          "product": "مضاد حيوي", "date": TODAY, "withdrawal_days": 10}
    assert client.post("/api/health", headers=h, json=ev).status_code == 200
    r = client.post(f"/api/animals/{a['id']}/sell", headers=h, json={"price": 40000})
    assert r.status_code == 409 and (date.today() + timedelta(days=10)).isoformat() in r.json()["detail"]
    ok = client.post(f"/api/animals/{a['id']}/sell", headers=h,
                     json={"price": 40000, "date": (date.today() + timedelta(days=10)).isoformat()})
    assert ok.status_code == 200 and ok.json()["animal"]["status"] == "sold"
    txs = client.get("/api/transactions", headers=h).json()
    assert len(txs) == 1 and txs[0]["amount"] == 40000
    assert client.post(f"/api/animals/{a['id']}/sell", headers=h, json={"price": 1}).status_code == 409


def test_group_withdrawal_applies_to_members(client):
    h, _ = register(client)
    g = client.get("/api/groups", headers=h).json()[0]
    a = mk_animal(client, h, "G-1", group_id=g["id"])
    client.post("/api/health", headers=h, json={"target_type": "group", "target_id": g["id"],
                                                "kind": "vaccine", "date": TODAY, "withdrawal_days": 5})
    assert client.post(f"/api/animals/{a['id']}/sell", headers=h, json={"price": 1}).status_code == 409


def test_plan_limit_and_duplicate_tag(client):
    h, _ = register(client)
    old = PLAN_LIMITS["free"]
    PLAN_LIMITS["free"] = 2
    try:
        mk_animal(client, h, "L-1")
        mk_animal(client, h, "L-2")
        assert client.post("/api/animals", headers=h, json={"tag": "L-3"}).status_code == 402
        assert client.post("/api/animals", headers=h, json={"tag": "L-1"}).status_code in (402, 409)
    finally:
        PLAN_LIMITS["free"] = old
    assert client.post("/api/animals", headers=h, json={"tag": "L-1"}).status_code == 409


def test_validation(client):
    h, _ = register(client)
    a = mk_animal(client, h, "V-1")
    bad = {"animal_id": a["id"], "date": "2025-13-40", "kg": 30}
    assert client.post("/api/weights", headers=h, json=bad).status_code == 422
    assert client.post("/api/weights", headers=h, json={**bad, "date": TODAY, "kg": -5}).status_code == 422


def test_sync_last_write_wins_and_pull(client):
    h, _ = register(client)
    aid = "a" * 32
    r1 = client.post("/api/sync", headers=h, json={"changes": {"animal": [
        {"id": aid, "tag": "SYNC-1", "client_ts": 2000}]}}).json()
    assert not r1["rejected"]
    client.post("/api/sync", headers=h, json={"changes": {"animal": [
        {"id": aid, "tag": "OLD", "client_ts": 1000}]}})
    r3 = client.post("/api/sync", headers=h, json={"last_pulled": 0}).json()
    animals = r3["changes"]["animal"]
    assert [a["tag"] for a in animals] == ["SYNC-1"]
    # تعديل أحدث يفوز، والحذف الناعم يصل للعميل الآخر عبر السحب
    client.post("/api/sync", headers=h, json={"changes": {"animal": [
        {"id": aid, "tag": "SYNC-1", "client_ts": 3000, "deleted": True}]}})
    pulled = client.post("/api/sync", headers=h, json={"last_pulled": r3["server_time"]}).json()
    assert pulled["changes"]["animal"][0]["deleted"] is True
    assert client.get("/api/animals", headers=h).json() == []
    # رفض سجل غير صالح دون إفشال الباقي
    mix = client.post("/api/sync", headers=h, json={"changes": {"weight": [
        {"id": "w" * 32, "animal_id": aid, "date": "bad", "kg": 3},
        {"id": "x" * 32, "animal_id": aid, "date": TODAY, "kg": 30}]}}).json()
    assert len(mix["rejected"]) == 1 and len(mix["changes"]["weight"]) == 1


def test_dashboard(client):
    h, _ = register(client)
    items = client.get("/api/stock-items", headers=h).json()
    it = next(i for i in items if i["name"] == "شعير")
    client.put(f"/api/stock-items/{it['id']}", headers=h, json={"name": "شعير", "opening": 30, "daily_use": 6, "min_days": 10})
    client.post("/api/stock-moves", headers=h, json={"item_id": it["id"], "date": TODAY, "delta": -6})
    client.post("/api/tasks", headers=h, json={"title": "متأخرة", "due": (date.today() - timedelta(days=2)).isoformat()})
    client.post("/api/transactions", headers=h, json={"date": TODAY, "type": "in", "category": "بيع", "amount": 500})
    client.post("/api/transactions", headers=h, json={"date": TODAY, "type": "out", "category": "علف", "amount": 200})
    d = client.get("/api/dashboard", headers=h).json()
    barley = next(s for s in d["stock"] if s["name"] == "شعير")
    assert barley["qty"] == 24 and barley["days"] == 4.0 and barley["low"] is True
    assert d["overdue_tasks"] == 1 and d["month"] == {"income": 500, "expense": 200}


def test_withdrawal_enforced_on_sync_path(client):
    """الرأس لا يصير «مباعًا» عبر المزامنة أثناء مدة السحب (تطبيق الهاتف لا يتجاوز القاعدة)."""
    h, _ = register(client)
    aid = "b" * 32
    client.post("/api/sync", headers=h, json={"changes": {
        "animal": [{"id": aid, "tag": "SY-1", "client_ts": 1000}],
        "health": [{"id": "e" * 32, "target_type": "animal", "target_id": aid, "kind": "treatment",
                    "product": "مضاد", "date": TODAY, "withdrawal_days": 7, "client_ts": 1000}]}})
    r = client.post("/api/sync", headers=h, json={"changes": {"animal": [
        {"id": aid, "tag": "SY-1", "status": "sold", "client_ts": 5000}]}}).json()
    assert r["rejected"] and r["rejected"][0]["status"] == 409
    assert client.get("/api/animals", headers=h).json()[0]["status"] == "active"
