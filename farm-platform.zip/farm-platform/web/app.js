'use strict';
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const f = n => Math.round(n || 0).toLocaleString('fr-FR');
const today = () => new Date().toISOString().slice(0, 10);
let session = null, tab = 'dash', regMode = false;
try { session = JSON.parse(localStorage.getItem('farm_session')); } catch (e) {}

function toast(t) { const m = $('#toast'); m.textContent = t; m.style.display = 'block'; setTimeout(() => m.style.display = 'none', 3200); }

async function api(path, opt = {}) {
  const r = await fetch('/api' + path, {
    method: opt.method || 'GET',
    headers: {'Content-Type': 'application/json', ...(session ? {Authorization: 'Bearer ' + session.token} : {})},
    body: opt.body ? JSON.stringify(opt.body) : undefined
  });
  if (r.status === 401 && session && !path.startsWith('/auth')) { logout(); throw new Error('انتهت الجلسة، سجّل الدخول من جديد'); }
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(typeof data.detail === 'string' ? data.detail : 'تعذّر تنفيذ الطلب');
  return data;
}
const act = async fn => { try { await fn(); } catch (e) { toast(e.message); } };

function logout() { session = null; try { localStorage.removeItem('farm_session'); } catch (e) {} boot(); }
function boot() {
  $('#auth').hidden = !!session; $('#shell').hidden = !session;
  if (!session) return;
  $('#farmName').textContent = session.tenant.name;
  $('#who').textContent = session.user.name + ' (' + ROLES[session.user.role] + ')';
  render();
}
const ROLES = {owner: 'مالك', supervisor: 'مشرف', worker: 'عامل', vet: 'بيطري'};

$('#authToggle').onclick = () => {
  regMode = !regMode; $('#regFields').hidden = !regMode;
  $('#authBtn').textContent = regMode ? 'إنشاء الحساب' : 'دخول';
  $('#authToggle').textContent = regMode ? 'لدي حساب بالفعل' : 'إنشاء حساب مزرعة جديدة';
};
$('#authForm').onsubmit = async e => {
  e.preventDefault(); $('#authErr').textContent = '';
  const v = Object.fromEntries(new FormData(e.target));
  try {
    session = await api(regMode ? '/auth/register' : '/auth/login', {method: 'POST', body: v});
    try { localStorage.setItem('farm_session', JSON.stringify(session)); } catch (e) {}
    boot();
  } catch (err) { $('#authErr').textContent = err.message; }
};
$('#logout').onclick = logout;

const TABS = [['dash', 'لوحة القيادة'], ['animals', 'القطيع والأوزان'], ['stock', 'المخزون'], ['tasks', 'المهام'], ['fin', 'المالية'], ['team', 'الفريق']];
const can = (...r) => r.includes(session.user.role);
async function render() {
  $('#nav').innerHTML = TABS.filter(t => t[0] != 'team' || can('owner')).map(t => `<button class="${t[0] == tab ? 'on' : ''}" data-t="${t[0]}">${t[1]}</button>`).join('');
  $('#nav').querySelectorAll('button').forEach(b => b.onclick = () => { tab = b.dataset.t; render(); });
  try { $('#view').innerHTML = await VIEWS[tab](); } catch (e) { $('#view').innerHTML = `<p class="err">${esc(e.message)}</p>`; }
}
const kpi = (l, v, hot) => `<div class="k ${hot ? 'hot' : ''}"><small>${l}</small><b>${v}</b></div>`;

const VIEWS = {
  async dash() {
    const [d, tasks] = await Promise.all([api('/dashboard'), api('/tasks')]);
    const al = [];
    d.stock.filter(s => s.low).forEach(s => al.push(['bad', `مخزون ${s.name} يكفي ${s.days} أيام فقط`]));
    if (d.overdue_tasks) al.push(['warn', `${d.overdue_tasks} مهام متأخرة`]);
    if (d.laying_rate !== null && d.laying_rate < .7) al.push(['warn', `نسبة البيض ${Math.round(d.laying_rate * 100)}% أقل من 70%`]);
    return `<div class="grid">${kpi('رؤوس نشطة', f(d.animals))}${kpi('دجاج البياض', f(d.poultry.layers))}${kpi('دجاج اللحم', f(d.poultry.broilers))}${kpi('بيض اليوم', f(d.eggs_today))}${kpi('إيراد الشهر', f(d.month.income))}${kpi('مصاريف الشهر', f(d.month.expense))}${kpi('تنبيهات', al.length, al.length)}</div>
    <div class="card"><h3>التنبيهات</h3>${al.map(a => `<p class="al ${a[0]}">${esc(a[1])}</p>`).join('') || '<p class="mut">لا تنبيهات الآن.</p>'}</div>
    <div class="card"><h3>المخزون</h3><table><tr><th>الصنف</th><th>الكمية</th><th>يكفي</th></tr>${d.stock.map(s => `<tr><td>${esc(s.name)}</td><td>${f(s.qty)} ${esc(s.unit)}</td><td class="${s.low ? 'badt' : ''}">${s.days ?? '—'} يومًا</td></tr>`).join('')}</table></div>`;
  },
  async animals() {
    const [an, gr, w] = await Promise.all([api('/animals'), api('/groups'), api('/weights')]);
    const gname = Object.fromEntries(gr.map(g => [g.id, g.name]));
    const by = {}; w.forEach(x => (by[x.animal_id] ??= []).push(x));
    const rows = an.filter(a => a.status == 'active').map(a => {
      const ws = (by[a.id] || []).sort((x, y) => x.date.localeCompare(y.date));
      const last = ws.at(-1); let adg = '—', bad = false;
      if (ws.length > 1) { const d = (new Date(last.date) - new Date(ws[0].date)) / 864e5; if (d > 0) { const g = (last.kg - ws[0].kg) * 1000 / d; adg = Math.round(g) + ' غ/يوم'; bad = g < 150; } }
      return `<tr><td>${esc(a.tag)}</td><td>${esc(gname[a.group_id] || '')}</td><td>${last ? last.kg + ' كلغ' : '—'}</td><td class="${bad ? 'badt' : ''}">${adg}</td><td><button class="s" data-w="${a.id}">وزن</button> <button class="s" data-h="${a.id}">علاج</button> ${can('owner', 'supervisor') ? `<button class="s" data-s="${a.id}">بيع</button>` : ''}</td></tr>`;
    }).join('');
    queueMicrotask(() => {
      $('#addAnimal').onsubmit = e => { e.preventDefault(); const v = Object.fromEntries(new FormData(e.target)); act(async () => { await api('/animals', {method: 'POST', body: v}); toast('تمت الإضافة'); render(); }); };
      document.querySelectorAll('[data-w]').forEach(b => b.onclick = () => { const kg = parseFloat(prompt('الوزن بالكلغ')); if (kg > 0) act(async () => { await api('/weights', {method: 'POST', body: {animal_id: b.dataset.w, date: today(), kg}}); render(); }); });
      document.querySelectorAll('[data-h]').forEach(b => b.onclick = () => { const product = prompt('اسم الدواء أو اللقاح'); if (!product) return; const days = parseInt(prompt('مدة السحب بالأيام (0 إن لا توجد)', '0')) || 0; act(async () => { await api('/health', {method: 'POST', body: {target_type: 'animal', target_id: b.dataset.h, kind: days ? 'treatment' : 'vaccine', product, date: today(), withdrawal_days: days}}); toast('تم التسجيل'); }); });
      document.querySelectorAll('[data-s]').forEach(b => b.onclick = () => { const price = parseFloat(prompt('سعر البيع (دج)')); if (price > 0) act(async () => { await api(`/animals/${b.dataset.s}/sell`, {method: 'POST', body: {price}}); toast('تم البيع وتسجيل الإيراد'); render(); }); });
    });
    return `<div class="card"><h3>رأس جديد</h3><form id="addAnimal" class="row"><label>رقم التعريف<input name="tag" required></label><label>السلالة<select name="group_id">${gr.filter(g => ['sheep', 'goat'].includes(g.kind)).map(g => `<option value="${g.id}">${esc(g.name)}</option>`).join('')}</select></label><label>الجنس<select name="sex"><option value="F">أنثى</option><option value="M">ذكر</option></select></label><button class="btn">أضف</button></form></div>
    <div class="card"><table><tr><th>الرقم</th><th>السلالة</th><th>آخر وزن</th><th>الزيادة اليومية</th><th></th></tr>${rows || '<tr><td colspan="5" class="mut">لا رؤوس بعد. أضف أول رأس.</td></tr>'}</table></div>`;
  },
  async stock() {
    const d = await api('/dashboard');
    queueMicrotask(() => document.querySelectorAll('[data-m]').forEach(b => b.onclick = () => { const q = parseFloat(prompt('الكمية')); if (q > 0) act(async () => { await api('/stock-moves', {method: 'POST', body: {item_id: b.dataset.m, date: today(), delta: q * +b.dataset.sign}}); render(); }); }));
    return `<div class="card"><table><tr><th>الصنف</th><th>الكمية</th><th>يكفي</th><th></th></tr>${d.stock.map(s => `<tr><td>${esc(s.name)}</td><td>${f(s.qty)} ${esc(s.unit)}</td><td class="${s.low ? 'badt' : ''}">${s.days ?? '—'} يومًا</td><td><button class="s" data-m="${s.id}" data-sign="1">استلام</button> <button class="s" data-m="${s.id}" data-sign="-1">صرف</button></td></tr>`).join('')}</table></div>`;
  },
  async tasks() {
    const t = (await api('/tasks')).sort((a, b) => a.done - b.done || a.due.localeCompare(b.due));
    queueMicrotask(() => {
      $('#addTask').onsubmit = e => { e.preventDefault(); const v = Object.fromEntries(new FormData(e.target)); act(async () => { await api('/tasks', {method: 'POST', body: v}); render(); }); };
      document.querySelectorAll('[data-d]').forEach(c => c.onchange = () => act(async () => { const x = t.find(y => y.id == c.dataset.d); await api('/tasks/' + x.id, {method: 'PUT', body: {...x, done: c.checked}}); render(); }));
    });
    return `<div class="card"><form id="addTask" class="row"><label>المهمة<input name="title" required></label><label>الموعد<input name="due" type="date" value="${today()}" required></label><button class="btn">أضف</button></form></div><div class="card"><table>${t.map(x => `<tr><td><label style="margin:0"><input type="checkbox" data-d="${x.id}" ${x.done ? 'checked' : ''} style="display:inline;width:auto"> ${esc(x.title)}</label></td><td class="${!x.done && x.due < today() ? 'badt' : 'mut'}">${x.due}</td></tr>`).join('') || '<tr><td class="mut">لا مهام. أضف أول مهمة.</td></tr>'}</table></div>`;
  },
  async fin() {
    if (!can('owner', 'supervisor')) return '<p class="mut">هذا القسم للمالك والمشرف.</p>';
    const [tx, d] = await Promise.all([api('/transactions'), api('/dashboard')]);
    queueMicrotask(() => $('#addTx').onsubmit = e => { e.preventDefault(); const v = Object.fromEntries(new FormData(e.target)); v.amount = +v.amount; act(async () => { await api('/transactions', {method: 'POST', body: v}); render(); }); });
    return `<div class="grid">${kpi('إيراد الشهر', f(d.month.income))}${kpi('مصاريف الشهر', f(d.month.expense))}${kpi('الصافي', f(d.month.income - d.month.expense))}</div>
    <div class="card"><form id="addTx" class="row"><label>النوع<select name="type"><option value="in">إيراد</option><option value="out">مصروف</option></select></label><label>البند<input name="category" required></label><label>المبلغ (دج)<input name="amount" type="number" min="1" required></label><label>التاريخ<input name="date" type="date" value="${today()}"></label><button class="btn">سجّل</button></form></div>
    <div class="card"><table>${tx.sort((a, b) => b.date.localeCompare(a.date)).slice(0, 30).map(x => `<tr><td>${x.date}</td><td>${esc(x.category)}</td><td class="${x.type == 'out' ? 'badt' : ''}">${x.type == 'out' ? '−' : '+'}${f(x.amount)}</td></tr>`).join('')}</table></div>`;
  },
  async team() {
    const u = await api('/users');
    queueMicrotask(() => $('#addUser').onsubmit = e => { e.preventDefault(); act(async () => { await api('/users', {method: 'POST', body: Object.fromEntries(new FormData(e.target))}); toast('تمت إضافة المستعمل'); render(); }); });
    return `<div class="card"><h3>مستعمل جديد</h3><form id="addUser" class="row"><label>الاسم<input name="name" required></label><label>البريد<input name="email" type="email" required></label><label>كلمة المرور<input name="password" type="password" minlength="8" required></label><label>الدور<select name="role"><option value="worker">عامل</option><option value="supervisor">مشرف</option><option value="vet">بيطري</option></select></label><button class="btn">أضف</button></form></div>
    <div class="card"><table>${u.map(x => `<tr><td>${esc(x.name)}</td><td>${esc(x.email)}</td><td>${ROLES[x.role]}</td></tr>`).join('')}</table></div>`;
  }
};
boot();
